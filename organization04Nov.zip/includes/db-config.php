<?php
  $hostname = "localhost";
  $username = "root";
  $password = "";
  $database = "organization_structure";
  $conn = mysqli_connect("$hostname", "$username", "$password", "$database");
  
 
  include('config.php');

?>