<?php  

$app_title = "Edtech Organizational Structure";
$organization_name = "";
$default_center_code_suffix = "";
$logged_in_users = "";
$not_able_to_logged_in_users = "";
$dark_logo = "";
$dark_logo_ratina = "";
$light_logo = "";
$light_logo_retina = "";
$login_cover = "";

?>