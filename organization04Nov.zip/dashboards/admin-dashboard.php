<?php 
echo "<pre>";
print_r($_SERVER['REQUEST_URI']);
echo "</pre>";
?>